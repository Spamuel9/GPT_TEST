/*
 * Simple Tetris game written in vanilla JavaScript.
 * Use the arrow keys to move and rotate the falling tetrominoes:
 *  - Left arrow moves the piece left
 *  - Right arrow moves the piece right
 *  - Up arrow rotates the piece
 *  - Down arrow drops the piece one row
 *
 * When a horizontal line is filled, it will be cleared and the score increases.
 * The game ends when new pieces can no longer enter the play field.
 */

const canvas = document.getElementById('game');
const context = canvas.getContext('2d');

// Scale up drawing to make each block 20x20 pixels
const BLOCK_SIZE = 20;
context.scale(BLOCK_SIZE, BLOCK_SIZE);

// Create the game board: 20 rows x 10 columns
const ROWS = 20;
const COLS = 10;

// The arena holds the fixed pieces once they land
function createMatrix(w, h) {
    const matrix = [];
    while (h--) {
        matrix.push(new Array(w).fill(0));
    }
    return matrix;
}
const arena = createMatrix(COLS, ROWS);

// Define the seven standard Tetris shapes and their identifiers
function createPiece(type) {
    switch (type) {
        case 'T':
            return [
                [0, 0, 0],
                [1, 1, 1],
                [0, 1, 0],
            ];
        case 'O':
            return [
                [2, 2],
                [2, 2],
            ];
        case 'L':
            return [
                [0, 3, 0],
                [0, 3, 0],
                [0, 3, 3],
            ];
        case 'J':
            return [
                [0, 4, 0],
                [0, 4, 0],
                [4, 4, 0],
            ];
        case 'I':
            return [
                [0, 5, 0, 0],
                [0, 5, 0, 0],
                [0, 5, 0, 0],
                [0, 5, 0, 0],
            ];
        case 'S':
            return [
                [0, 6, 6],
                [6, 6, 0],
                [0, 0, 0],
            ];
        case 'Z':
            return [
                [7, 7, 0],
                [0, 7, 7],
                [0, 0, 0],
            ];
        default:
            // Default to T piece
            return [
                [0, 0, 0],
                [1, 1, 1],
                [0, 1, 0],
            ];
    }
}

// Colors corresponding to shape identifiers
const COLORS = [
    null,
    '#FF0D72', // T
    '#0DC2FF', // O
    '#0DFF72', // L
    '#F538FF', // J
    '#FF8E0D', // I
    '#FFE138', // S
    '#3877FF', // Z
];

// Player state: current piece, its position, and the score
const player = {
    pos: { x: 0, y: 0 },
    matrix: null,
    score: 0,
};

// Reset the player with a new random piece
function playerReset() {
    const pieces = 'TJLOSZI';
    const randPiece = pieces[(pieces.length * Math.random()) | 0];
    player.matrix = createPiece(randPiece);
    player.pos.y = 0;
    player.pos.x =
        ((arena[0].length / 2) | 0) - ((player.matrix[0].length / 2) | 0);
    // If the new piece collides immediately, game over
    if (collide(arena, player)) {
        arena.forEach(row => row.fill(0));
        player.score = 0;
        updateScore();
    }
}

// Merge the player's piece into the arena when it lands
function merge(arena, player) {
    player.matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value !== 0) {
                arena[y + player.pos.y][x + player.pos.x] = value;
            }
        });
    });
}

// Check for collisions between the player's piece and the arena boundaries or other blocks
function collide(arena, player) {
    const m = player.matrix;
    const o = player.pos;
    for (let y = 0; y < m.length; ++y) {
        for (let x = 0; x < m[y].length; ++x) {
            if (
                m[y][x] !== 0 &&
                (arena[y + o.y] &&
                    arena[y + o.y][x + o.x]) !== 0
            ) {
                return true;
            }
        }
    }
    return false;
}

// Clear full rows and update the player's score
function arenaSweep() {
    let rowCount = 0;
    outer: for (let y = arena.length - 1; y >= 0; --y) {
        for (let x = 0; x < arena[y].length; ++x) {
            if (arena[y][x] === 0) {
                continue outer;
            }
        }
        const row = arena.splice(y, 1)[0].fill(0);
        arena.unshift(row);
        ++rowCount;
        ++y;
    }
    if (rowCount > 0) {
        player.score += rowCount * 10;
        updateScore();
    }
}

// Rotate the current piece matrix in place
function rotate(matrix, dir) {
    for (let y = 0; y < matrix.length; ++y) {
        for (let x = 0; x < y; ++x) {
            [matrix[x][y], matrix[y][x]] = [
                matrix[y][x],
                matrix[x][y],
            ];
        }
    }
    if (dir > 0) {
        matrix.forEach(row => row.reverse());
    } else {
        matrix.reverse();
    }
}

// Handle the rotation of the player's piece, with wall kick
function playerRotate(dir) {
    const pos = player.pos.x;
    let offset = 1;
    rotate(player.matrix, dir);
    while (collide(arena, player)) {
        player.pos.x += offset;
        offset = -(offset + (offset > 0 ? 1 : -1));
        if (offset > player.matrix[0].length) {
            rotate(player.matrix, -dir);
            player.pos.x = pos;
            return;
        }
    }
}

// Drop the player's piece by one row
function playerDrop() {
    player.pos.y++;
    if (collide(arena, player)) {
        player.pos.y--;
        merge(arena, player);
        playerReset();
        arenaSweep();
    }
    dropCounter = 0;
}

// Move the player's piece horizontally
function playerMove(dir) {
    player.pos.x += dir;
    if (collide(arena, player)) {
        player.pos.x -= dir;
    }
}

// Draw a block for a cell value at given offset
function drawMatrix(matrix, offset) {
    matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value !== 0) {
                context.fillStyle = COLORS[value];
                context.fillRect(
                    x + offset.x,
                    y + offset.y,
                    1,
                    1
                );
            }
        });
    });
}

// Draw the entire scene (arena + current piece)
function draw() {
    // Clear the canvas
    context.fillStyle = '#111';
    context.fillRect(0, 0, canvas.width, canvas.height);

    drawMatrix(arena, { x: 0, y: 0 });
    drawMatrix(player.matrix, player.pos);
}

// Update loop variables for dropping pieces based on time
let dropCounter = 0;
let dropInterval = 1000;
let lastTime = 0;

function update(time = 0) {
    const deltaTime = time - lastTime;
    lastTime = time;
    dropCounter += deltaTime;
    if (dropCounter > dropInterval) {
        playerDrop();
    }
    draw();
    requestAnimationFrame(update);
}

// Update score display in the DOM
function updateScore() {
    document.getElementById('score').innerText = `Score: ${player.score}`;
}

// Set up key controls
document.addEventListener('keydown', event => {
    switch (event.keyCode) {
        case 37: // left
            playerMove(-1);
            break;
        case 39: // right
            playerMove(1);
            break;
        case 40: // down
            playerDrop();
            break;
        case 38: // up (rotate)
            playerRotate(1);
            break;
    }
});

// Initialize the game
playerReset();
updateScore();
update();